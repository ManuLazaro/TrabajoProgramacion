package com.inicio.pantallainicial;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EditarEquipoDificil {
    @FXML
    private ListView<Jugadores> playerListView;
    @FXML
    private Button btnVolver;
    @FXML
    private Button btnJugar;
    @FXML
    private Button btnseleccionarJugador;
    private ObservableList<Jugadores> jugadores;
    private Equipo equipoMain;
    public Equipo getEquipoMain() {
        return equipoMain;
    }
    private ArrayList<Jugadores> selectedPlayersList;

    @FXML
    void volver(ActionEvent event) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Dificultad.fxml"));
        try{
            Parent root = fxmlLoader.load();
            Dificultad controlador = fxmlLoader.getController();

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("NBA Manager");
            stage.setScene(scene);

            stage.show();
        } catch (IOException e){
            throw new RuntimeException(e);
        }

        Stage stagePrincipal = (Stage) btnVolver.getScene().getWindow();
        stagePrincipal.close();
    }

    @FXML
    private void initialize() {
        DBManager.loadDriver();
        DBManager.connect();
        jugadores = FXCollections.observableArrayList();
        ResultSet rs = DBManager.getTablaJugadores(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        if (rs != null) {
            try {
                while (rs.next()) {
                    String nombre = rs.getString("Nombre");
                    int tiro = rs.getInt("Tiro");
                    int destreza = rs.getInt("Destreza");
                    int defensa = rs.getInt("Defensa");
                    String posicion = rs.getString("Posicion");
                    jugadores.add(new Jugadores(nombre, tiro, destreza, defensa, posicion));
                }
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        playerListView.setItems(jugadores);
        playerListView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        DBManager.close();
    }

    public static int resultadoMainDificilTotal = 0;
    public static int resultadoEquipoDificilMain = 0 ;
    public static int resultadoEquipoDificil = 0 ;

    @FXML
    void seleccionarJugador(ActionEvent event) {
        ObservableList<Jugadores> selectedPlayers = playerListView.getSelectionModel().getSelectedItems();
        selectedPlayersList = new ArrayList<>(selectedPlayers);

        equipoMain = new Equipo("EquipoMain");

        for (Jugadores jugador : selectedPlayers) {
            Jugadores nuevoJugador = new Jugadores(jugador.getNombre(), jugador.getTiro(), jugador.getDestreza(),
                    jugador.getDefensa(), jugador.getPosicion());
            System.out.println("Jugador seleccionado: " + jugador.getNombre());

            equipoMain.agregarJugador(nuevoJugador);
        }

        if (selectedPlayersList.size() == 5) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Equipo seleccionado");
            alert.setHeaderText(null);
            alert.setContentText("Equipo seleccionado: " + equipoMain.getNombre());
            alert.showAndWait();
        }

        Equipo equipoMain = getEquipoMain();
        Equipo equipoDificil = new Equipo("EquipoDificil");

        equipoDificil.agregarJugador(new Jugadores("Joel Embid", 79, 89, 90, "Pivot"));
        equipoDificil.agregarJugador(new Jugadores("Ja Morant", 60, 90, 60, "Base"));
        equipoDificil.agregarJugador(new Jugadores("Kevin Durant", 90, 80, 70, "Alero"));
        equipoDificil.agregarJugador(new Jugadores("Stephen Curry", 99, 85, 65, "Base"));
        equipoDificil.agregarJugador(new Jugadores("Demar Derozan", 79, 80, 80, "Escolta"));

        ArrayList<Jugadores> jugadoresMain = equipoMain.obtenerJugadores();
        ArrayList<Jugadores> jugadoresDificil = equipoDificil.obtenerJugadores();

        for (int i = 0; i < jugadoresMain.size(); i++) {
            Jugadores jugadorMain = jugadoresMain.get(i);
            Jugadores jugadorDificil = jugadoresDificil.get(i);

            int diferenciaTiro = jugadorMain.getTiro() - jugadorDificil.getTiro();
            int diferenciaDestreza = jugadorMain.getDestreza() - jugadorDificil.getDestreza();
            int diferenciaDefensa = jugadorMain.getDefensa() - jugadorDificil.getDefensa();

            int diferenciaFinal = diferenciaTiro + diferenciaDestreza + diferenciaDefensa;
            resultadoMainDificilTotal = resultadoMainDificilTotal + diferenciaFinal;
            System.out.println("Diferencia del jugador " + jugadorMain.getNombre() + " con " + jugadorDificil + " :");
            System.out.println("Diferencia de tiro: " + diferenciaTiro);
            System.out.println("Diferencia de destreza: " + diferenciaDestreza);
            System.out.println("Diferencia de defensa: " + diferenciaDefensa);

            System.out.println("Diferencia total actual : " + resultadoMainDificilTotal);
        }
    }

    @FXML
    void jugar(ActionEvent event) {
        if (resultadoMainDificilTotal > 0 && resultadoMainDificilTotal < 10) {
            resultadoEquipoDificilMain = (int) (Math.random() * 21) + 90;

            System.out.println("Puntos de tu equipo = " + resultadoEquipoDificilMain);
            resultadoEquipoDificil = (int) (Math.random() * 16) + 85;
            System.out.println("Puntos del rival = " + resultadoEquipoDificil);
        } else if (resultadoMainDificilTotal < 0 && resultadoMainDificilTotal > -10) {
            resultadoEquipoDificilMain = (int) (Math.random() * 16) + 85;
            System.out.println("Puntos de tu equipo = " + resultadoEquipoDificilMain);
            resultadoEquipoDificil = (int) (Math.random() * 21) + 90;
            System.out.println("Puntos del rival = " + resultadoEquipoDificil);
        } else if (resultadoMainDificilTotal < -10) {
            resultadoEquipoDificilMain = (int) (Math.random() * 16) + 75;
            System.out.println("Puntos de tu equipo = " + resultadoEquipoDificilMain);
            resultadoEquipoDificil = (int) (Math.random() * 26) + 85;
            System.out.println("Puntos del rival = " + resultadoEquipoDificil);
        } else {
            resultadoEquipoDificilMain = (int) (Math.random() * 26) + 85;
            System.out.println("Increíble! Puntos de tu equipo = " + resultadoEquipoDificilMain);
            resultadoEquipoDificil = (int) (Math.random() * 14) + 75;
            System.out.println("Puntos del rival = " + resultadoEquipoDificil);
        }
        // Mostrar la ventana "JugandoFacil"
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("JugandoDificil.fxml"));
        try {
            Parent root = fxmlLoader.load();
            JugandoDificil controller = fxmlLoader.getController();

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("Jugando - Difícil");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Stage stagePrincipal = (Stage) btnJugar.getScene().getWindow();
        stagePrincipal.close();
    }
}
