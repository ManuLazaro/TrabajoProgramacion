package com.inicio.pantallainicial;

public class App {
    public static void main(String[] args) {
        InicioApplication.main(args);
    }
}
