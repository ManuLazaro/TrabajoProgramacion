package com.inicio.pantallainicial;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

import static com.inicio.pantallainicial.DBManager.usuarioNombre;
import static com.inicio.pantallainicial.EditarEquipoController.resultadoEquipoFacil;
import static com.inicio.pantallainicial.EditarEquipoController.resultadoEquipoMain;


public class JugandoFacil {

    @FXML
    private Button btnJugar;

    @FXML
    private Button btnSalir;

    @FXML
    private Text txtPuntosRival;

    @FXML
    private Text txtPuntosUsuario;

    @FXML
    void jugar(ActionEvent event) {
        // Llamar a los métodos para establecer los valores de los textos
        setPuntosUsuario(resultadoEquipoMain);
        setPuntosRival(resultadoEquipoFacil);

        // Alertas segun el resultado
        if (resultadoEquipoMain > resultadoEquipoFacil) {
            // Alerta cuando resultadoEquipoMain es mayor que resultadoEquipoFacil
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Resultado del juego");
            alert.setHeaderText(null);
            alert.setContentText("¡Has ganado! ENHORABUENA.");
            alert.showAndWait();
        } else if (resultadoEquipoMain == resultadoEquipoFacil) {
            // Alerta cuando resultadoEquipoMain y resultadoEquipoFacil son iguales
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Resultado del juego");
            alert.setHeaderText(null);
            alert.setContentText("Has empatado, elige un mejor equipo la proxima vez.");
            alert.showAndWait();
        } else {
            // Alerta cuando resultadoEquipoFacil es mayor que resultadoEquipoMain
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Resultado del juego");
            alert.setHeaderText(null);
            alert.setContentText("Has perdido. El equipo rival fue mejor que tu.");
            alert.showAndWait();
        }
        DBManager.loadDriver();
        DBManager.connect();
        DBManager.insertEstadistica(usuarioNombre, "Facil", resultadoEquipoMain + " - " + resultadoEquipoFacil);
        DBManager.close();
    }

    @FXML
    void salir(ActionEvent event) {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("MenuPrincipal.fxml"));
        try{
            Parent root = fxmlLoader.load();
            MenuPrincipalController controlador = fxmlLoader.getController();

            Scene scene = new Scene(root);
            Stage stage = new Stage();
            stage.setTitle("NBA Manager");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e){
            throw new RuntimeException(e);
        }

        Stage stagePrincipal = (Stage) btnSalir.getScene().getWindow();
        stagePrincipal.close();
    }
    public void setPuntosUsuario(int puntos) {
        txtPuntosUsuario.setText(Integer.toString(puntos));
    }

    public void setPuntosRival(int puntos) {
        txtPuntosRival.setText(Integer.toString(puntos));
    }

}

