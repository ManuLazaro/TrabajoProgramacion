package com.inicio.pantallainicial;

import java.util.ArrayList;
import java.util.List;

public class Equipo {
    private String nombre;
    private ArrayList<Jugadores> jugadores;

    public Equipo(String nombre) {
        this.nombre = nombre;
        this.jugadores = new ArrayList<>();
    }

    public void agregarJugador(Jugadores jugador) {
        jugadores.add(jugador);
    }

    public ArrayList<Jugadores> obtenerJugadores() {
        return jugadores;
    }

}

