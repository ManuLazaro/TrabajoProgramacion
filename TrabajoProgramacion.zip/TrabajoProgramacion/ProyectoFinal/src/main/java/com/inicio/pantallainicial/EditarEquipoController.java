package com.inicio.pantallainicial;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EditarEquipoController {
    @FXML
    private ListView<Jugadores> playerListView;
    @FXML
    void btnVolver(ActionEvent event) {

    }
    @FXML
    void btnCompararEquipos(ActionEvent event) {
        compararEquipos(event);
    }

    private ObservableList<Jugadores> jugadores;

    private Equipo equipoMain; // Variable miembro para almacenar el equipoMain

    public EditarEquipoController() {
        // Simulación de carga de jugadores desde la base de datos
        jugadores = FXCollections.observableArrayList(
                new Jugadores("Jugador 1", 80, 90, 70, "Delantero"),
                new Jugadores("Jugador 2", 85, 80, 75, "Base"),
                new Jugadores("Jugador 3", 90, 70, 85, "Pivot"),
                new Jugadores("Jugador 4", 75, 85, 90, "Ala-pívot")
        );
    }

    @FXML
    private void initialize() {
        // Obtener los jugadores de la base de datos y cargarlos en la lista
        jugadores = FXCollections.observableArrayList();
        ResultSet rs = DBManager.getTablaJugadores(ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
        if (rs != null) {
            try {
                while (rs.next()) {
                    String nombre = rs.getString("Nombre");
                    int tiro = rs.getInt("Tiro");
                    int destreza = rs.getInt("Destreza");
                    int defensa = rs.getInt("Defensa");
                    String posicion = rs.getString("Posicion");
                    jugadores.add(new Jugadores(nombre, tiro, destreza, defensa, posicion));
                }
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        playerListView.setItems(jugadores);
    }

    private ArrayList<Jugadores> selectedPlayersList;

    @FXML
    public void seleccionarJugador() {
        ObservableList<Jugadores> selectedPlayers = playerListView.getSelectionModel().getSelectedItems();
        selectedPlayersList = new ArrayList<>(selectedPlayers);

        // Crear el equipoMain y asignarlo a la variable miembro
        equipoMain = new Equipo("EquipoMain");

        for (Jugadores jugador : selectedPlayers) {
            Jugadores nuevoJugador = new Jugadores(jugador.getNombre(), jugador.getTiro(), jugador.getDestreza(),
                    jugador.getDefensa(), jugador.getPosicion());

            equipoMain.agregarJugador(nuevoJugador);
        }
    }

    public Equipo getEquipoMain() {
        return equipoMain;
    }
    @FXML
    void compararEquipos(ActionEvent event) {
        Equipo equipoMain = getEquipoMain(); // Obtener el equipoMain
        Equipo equipoFacil = new Equipo("EquipoFacil"); // Crear el equipoFacil

        // Agregar jugadores al equipoFacil
        equipoFacil.agregarJugador(new Jugadores("Lebron", 80, 90, 70, "Delantero"));
        equipoFacil.agregarJugador(new Jugadores("Curry", 85, 80, 75, "Base"));
        equipoFacil.agregarJugador(new Jugadores("Jokic", 90, 70, 85, "Pivot"));
        equipoFacil.agregarJugador(new Jugadores("AD", 75, 85, 90, "Ala-pívot"));
        equipoFacil.agregarJugador(new Jugadores("Herro", 70, 75, 80, "Escolta"));

        ArrayList<Jugadores> jugadoresMain = equipoMain.obtenerJugadores();
        ArrayList<Jugadores> jugadoresFacil = equipoFacil.obtenerJugadores();

        for (int i = 0; i < jugadoresMain.size(); i++) {
            Jugadores jugadorMain = jugadoresMain.get(i);
            Jugadores jugadorFacil = jugadoresFacil.get(i);

            int diferenciaTiro = jugadorMain.getTiro() - jugadorFacil.getTiro();
            int diferenciaDefensa = jugadorMain.getDefensa() - jugadorFacil.getDefensa();

            System.out.println("Diferencia del jugador " + jugadorMain.getNombre() + " con "+jugadorFacil+" :");
            System.out.println("Diferencia de tiro: " + diferenciaTiro);
            System.out.println("Diferencia de defensa: " + diferenciaDefensa);
            System.out.println();
        }
    }

}
